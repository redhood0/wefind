package com.wefind.context;
//物品分类：
//人0:(孩童（男1女2）成年人（男5女6）老年人（男10女11）)
//动物:30（公1母2）
//物品（日用品，证件，贵重物品，电子产品，图书，服装鞋帽，纪念品）
public class ClassificationContext {

}
